const translations = {
  en: {
    navAbout:"About",navHow:"How it works",navReport:"Report a concern",navDashboard:"Dashboard",
    eyebrow:"AN INDEPENDENT NATIONAL TECHNOLOGY INITIATIVE",heroTitle:"Technology for a more transparent Kenya.",
    heroCopy:"A citizen-focused platform designed to receive reports, analyse public-interest information and highlight possible corruption risks for human review.",
    reportButton:"Report a concern",learnButton:"Learn how it works",heroSafety:"A report or AI alert is not proof of corruption. Every concern requires fair, independent verification.",
    monitoring:"INTEGRITY MONITORING",citizenFirst:"Citizen first. Evidence always.",citizenCopy:"A secure and accessible starting point for accountability conversations across Kenya.",
    counties:"Counties",languages:"Language groups",access:"Access vision",principle1:"Fair process",principle2:"Privacy by design",principle3:"Evidence-led review",principle4:"Accessible to all",
    aboutEyebrow:"OUR PURPOSE",aboutTitle:"An independent platform for every Kenyan.",aboutCopy:"ANTI-CORRUPTION AI KENYA aims to help citizens raise concerns and help authorised reviewers identify patterns that may deserve further investigation.",
    feature1Title:"Spot warning signs",feature1Copy:"Analyse available procurement, expenditure and service-delivery data for unusual patterns.",feature2Title:"Hear from citizens",feature2Copy:"Provide a clear route for people to share concerns and supporting information.",feature3Title:"Support human review",feature3Copy:"Organise reports for trained reviewers. AI supports analysis; people make decisions.",
    processEyebrow:"HOW IT WORKS",processTitle:"From concern to responsible review.",step1Title:"Submit information",step1Copy:"A citizen describes a concern and may provide supporting evidence.",step2Title:"Screen for risk",step2Copy:"Future AI tools can help identify duplicates, anomalies and patterns.",step3Title:"Human verification",step3Copy:"Authorised reviewers assess reliability, context and fairness before action.",
    reportEyebrow:"CITIZEN REPORTING",reportTitle:"Share a concern responsibly.",reportIntro:"This demonstration form does not send or save information. Do not enter real names, identity numbers, passwords or sensitive evidence until a secure, legally reviewed reporting service is built.",
    privacyTitle:"Protect yourself and others",privacyCopy:"Only share information you believe is accurate and lawfully obtained. Avoid public accusations. Use official emergency or law-enforcement channels if someone is in immediate danger.",
    categoryLabel:"Type of concern",chooseOption:"Choose a category",countyLabel:"County",chooseCounty:"Choose county",dateLabel:"Approximate date",descriptionLabel:"Describe the concern",
    accuracyLabel:"I have provided information honestly and understand that allegations require verification.",submitButton:"Preview report",
    dashboardEyebrow:"NATIONAL VIEW",dashboardTitle:"A transparent view of the work.",dashboardCopy:"The figures below are illustrative placeholders for the prototype, not actual corruption statistics or live reports.",
    metric1:"Reports received",metric2:"Awaiting review",metric3:"Verified findings",placeholder:"Demo data not connected",footerCopy:"Independent national technology initiative • Built for public interest",
    footerLegal:"Prototype only. Not a government agency, law-enforcement body or official reporting channel. No report is submitted from this demo.",
    preview:"Demo preview created in this browser only. Nothing has been sent or saved.",missing:"Please complete the required fields and confirm the accuracy statement."
  },
  sw: {
    navAbout:"Kuhusu",navHow:"Jinsi inavyofanya kazi",navReport:"Ripoti suala",navDashboard:"Dashibodi",
    eyebrow:"MPANGO HURU WA KITAIFA WA TEKNOLOJIA",heroTitle:"Teknolojia kwa Kenya yenye uwazi zaidi.",
    heroCopy:"Jukwaa linalolenga wananchi kupokea ripoti, kuchanganua taarifa za umma na kuonyesha viashiria vinavyoweza kuashiria ufisadi ili vikaguliwe na binadamu.",
    reportButton:"Ripoti suala",learnButton:"Jifunze jinsi inavyofanya kazi",heroSafety:"Ripoti au tahadhari ya AI si uthibitisho wa ufisadi. Kila suala linahitaji uchunguzi wa haki na huru.",
    monitoring:"UFUATILIAJI WA UADILIFU",citizenFirst:"Wananchi kwanza. Ushahidi kila wakati.",citizenCopy:"Mwanzo salama na rahisi wa kuimarisha uwajibikaji kote Kenya.",
    counties:"Kaunti",languages:"Makundi ya lugha",access:"Dira ya ufikiaji",principle1:"Mchakato wa haki",principle2:"Faragha kwanza",principle3:"Uchunguzi unaotegemea ushahidi",principle4:"Ufikiaji kwa wote",
    aboutEyebrow:"LENGO LETU",aboutTitle:"Jukwaa huru kwa kila Mkenya.",aboutCopy:"ANTI-CORRUPTION AI KENYA inalenga kuwasaidia wananchi kuwasilisha masuala na kuwasaidia wakaguzi walioidhinishwa kutambua mifumo inayoweza kuhitaji uchunguzi zaidi.",
    feature1Title:"Tambua viashiria",feature1Copy:"Changanua data inayopatikana ya zabuni, matumizi ya fedha na utoaji wa huduma ili kutambua mifumo isiyo ya kawaida.",feature2Title:"Sikiliza wananchi",feature2Copy:"Toa njia wazi kwa watu kuwasilisha masuala na taarifa zinazounga mkono ripoti zao.",feature3Title:"Saidia ukaguzi wa binadamu",feature3Copy:"Panga ripoti kwa ajili ya wakaguzi waliofunzwa. AI husaidia uchanganuzi; binadamu hufanya maamuzi.",
    processEyebrow:"JINSI INAVYOFANYA KAZI",processTitle:"Kutoka kwenye taarifa hadi ukaguzi unaowajibika.",step1Title:"Wasilisha taarifa",step1Copy:"Mwananchi anaeleza suala na anaweza kutoa ushahidi unaounga mkono taarifa hiyo.",step2Title:"Chunguza viashiria",step2Copy:"Zana za AI za baadaye zinaweza kusaidia kutambua taarifa zinazojirudia, hitilafu na mifumo.",step3Title:"Uthibitishaji wa binadamu",step3Copy:"Wakaguzi walioidhinishwa hutathmini uaminifu, muktadha na haki kabla ya kuchukua hatua.",
    reportEyebrow:"RIPOTI ZA WANANCHI",reportTitle:"Wasilisha suala kwa uwajibikaji.",reportIntro:"Fomu hii ya majaribio haitumi wala kuhifadhi taarifa. Usiweke majina halisi, nambari za utambulisho, nywila au ushahidi nyeti hadi huduma salama iliyokaguliwa kisheria ijengwe.",
    privacyTitle:"Jilinde na uwalinde wengine",privacyCopy:"Shiriki tu taarifa unazoamini ni sahihi na zilizopatikana kisheria. Epuka tuhuma za hadharani. Tumia njia rasmi za dharura au vyombo vya sheria ikiwa mtu yuko hatarini mara moja.",
    categoryLabel:"Aina ya suala",chooseOption:"Chagua aina",countyLabel:"Kaunti",chooseCounty:"Chagua kaunti",dateLabel:"Tarehe ya makadirio",descriptionLabel:"Eleza suala",
    accuracyLabel:"Nimetoa taarifa kwa uaminifu na ninaelewa kuwa madai yanahitaji kuthibitishwa.",submitButton:"Onyesha rasimu ya ripoti",
    dashboardEyebrow:"MUHTASARI WA KITAIFA",dashboardTitle:"Mtazamo wa uwazi kuhusu kazi.",dashboardCopy:"Nambari zilizo hapa chini ni mifano ya muundo wa tovuti, si takwimu halisi za ufisadi wala ripoti za moja kwa moja.",
    metric1:"Ripoti zilizopokelewa",metric2:"Zinazosubiri ukaguzi",metric3:"Matokeo yaliyothibitishwa",placeholder:"Takwimu za majaribio hazijaunganishwa",footerCopy:"Mpango huru wa kitaifa wa teknolojia • Kwa manufaa ya umma",
    footerLegal:"Toleo la majaribio pekee. Si wakala wa serikali, chombo cha kutekeleza sheria au njia rasmi ya kuripoti. Hakuna ripoti inayotumwa kupitia toleo hili.",
    preview:"Rasimu ya majaribio imeundwa kwenye kivinjari hiki pekee. Hakuna taarifa iliyotumwa au kuhifadhiwa.",missing:"Tafadhali jaza sehemu zinazohitajika na uthibitishe tamko la usahihi."
  }
};
const languageSelect = document.getElementById('languageSelect');
function setLanguage(lang){
  const dict = translations[lang] || translations.en;
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key=el.dataset.i18n;
    if(dict[key]) el.textContent=dict[key];
  });
}
languageSelect.addEventListener('change',e=>setLanguage(e.target.value));
document.getElementById('reportForm').addEventListener('submit',e=>{
  e.preventDefault();
  const lang=languageSelect.value;
  const dict=translations[lang];
  const valid=document.getElementById('category').value &&
    document.getElementById('county').value &&
    document.getElementById('description').value.trim().length>=20 &&
    document.getElementById('accuracy').checked;
  document.getElementById('formMessage').textContent=valid?dict.preview:dict.missing;
});
