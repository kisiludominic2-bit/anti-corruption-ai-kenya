# ANTI-CORRUPTION AI KENYA — Prototype

A front-end demonstration for an independent, citizen-accessible Kenyan integrity-monitoring initiative.

## Included
- Responsive homepage and navigation
- English / Kiswahili language switch
- Citizen concern form with browser-only validation
- County and concern categories
- Dashboard placeholders
- Clear safeguards explaining that AI alerts and allegations are not proof

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in a modern web browser.
3. No installation or server is required for this visual prototype.

## Important limitations
This is a front-end prototype only:
- The form does not transmit, store, or protect reports.
- There is no login, database, AI model, evidence upload, or investigator portal.
- Dashboard values are placeholders, not real statistics.
- Do not enter real personal information or sensitive allegations into this demo.

## Recommended next development stage
Build a secure backend (for example, Django + PostgreSQL), authentication and role-based access, encrypted evidence storage, audit logging, abuse prevention, and a legally reviewed reporting process. Add AI risk-scoring only after establishing lawful data access, data quality, bias testing, explainability, and mandatory human review.

## Governance and legal safeguards
Before public launch, obtain Kenyan legal and cybersecurity advice. Establish privacy notices, data-protection impact assessment, retention and deletion rules, whistleblower safety procedures, moderation and appeal processes, and clear separation between allegations, risk indicators, and verified findings. Do not publish names or accusations based solely on reports or automated scores.
